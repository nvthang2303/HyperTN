
Erase FRP for fix sign in Google and set passcode in Android 15:

Connect via fastboot -> Run Erase_FPR.bat -> Done